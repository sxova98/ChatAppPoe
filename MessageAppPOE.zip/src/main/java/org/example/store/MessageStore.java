package org.example.store;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import org.example.model.Message;
import org.example.model.MessageFlag;
import org.example.util.Utils;

import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

/**
 * MessageStore keeps parallel lists for different sets of messages:
 * - sentMessages
 * - disregardedMessages
 * - storedMessages
 * - messageHashes
 * - messageIds
 *
 * Provides features required by the assignment.
 */
public class MessageStore {
    private final List<Message> sentMessages = new ArrayList<>();
    private final List<Message> disregardedMessages = new ArrayList<>();
    private final List<Message> storedMessages = new ArrayList<>();

    private final List<String> messageHashes = new ArrayList<>();
    private final List<String> messageIds = new ArrayList<>();

    public void addMessage(Message m) {
        messageIds.add(m.getId());
        messageHashes.add(m.getHash());
        switch (m.getFlag()) {
            case SENT -> sentMessages.add(m);
            case STORED -> storedMessages.add(m);
            case DISREGARD -> disregardedMessages.add(m);
            default -> throw new IllegalStateException("Unexpected flag: " + m.getFlag());
        }
    }

    public List<Message> getSentMessages() { return new ArrayList<>(sentMessages); }
    public List<Message> getDisregardedMessages() { return new ArrayList<>(disregardedMessages); }
    public List<Message> getStoredMessages() { return new ArrayList<>(storedMessages); }
    public List<String> getMessageHashes() { return new ArrayList<>(messageHashes); }
    public List<String> getMessageIds() { return new ArrayList<>(messageIds); }

    public List<String> displaySenderRecipientOfAllSent() {
        return sentMessages.stream()
                .map(m -> "Sender: " + (m.getSender() == null ? "(unknown)" : m.getSender()) + "; Recipient: " + m.getRecipient())
                .collect(Collectors.toList());
    }

    public Optional<Message> getLongestSentMessage() {
        return sentMessages.stream().max(Comparator.comparingInt(m -> m.getText().length()));
    }

    public Optional<Message> searchByMessageId(String id) {
        return allMessages().stream().filter(m -> m.getId().equals(id)).findFirst();
    }

    public List<Message> searchByRecipient(String recipient) {
        return allMessages().stream().filter(m -> m.getRecipient() != null && m.getRecipient().equals(recipient)).collect(Collectors.toList());
    }

    public boolean deleteByHash(String hash) {
        Optional<Message> found = allMessages().stream().filter(m -> m.getHash().equals(hash)).findFirst();
        if (found.isEmpty()) return false;
        Message m = found.get();
        messageHashes.remove(m.getHash());
        messageIds.remove(m.getId());
        switch (m.getFlag()) {
            case SENT -> sentMessages.remove(m);
            case STORED -> storedMessages.remove(m);
            case DISREGARD -> disregardedMessages.remove(m);
        }
        return true;
    }

    public String displayReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("Report of sent messages:\n");
        for (Message m : sentMessages) {
            sb.append("Message Hash: ").append(m.getHash()).append("\n");
            sb.append("Message ID: ").append(m.getId()).append("\n");
            sb.append("Recipient: ").append(m.getRecipient()).append("\n");
            sb.append("Message: ").append(m.getText()).append("\n");
            sb.append("---\n");
        }
        return sb.toString();
    }

    private List<Message> allMessages() {
        List<Message> all = new ArrayList<>();
        all.addAll(sentMessages);
        all.addAll(storedMessages);
        all.addAll(disregardedMessages);
        return all;
    }

    /**
     * Load messages from a JSON file. Expected JSON array with fields:
     * developer (optional), recipient (string), message (string), flag (SENT/STORED/DISREGARD)
     */
    public void loadFromJson(Path jsonFile) throws IOException {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader(jsonFile.toFile())) {
            Type listType = new TypeToken<List<JsonObject>>() {}.getType();
            List<JsonObject> jsonObjects = gson.fromJson(reader, listType);
            for (JsonObject obj : jsonObjects) {
                String developer = obj.has("developer") && !obj.get("developer").isJsonNull() ? obj.get("developer").getAsString() : null;
                String recipient = obj.has("recipient") && !obj.get("recipient").isJsonNull() ? obj.get("recipient").getAsString() : null;
                String messageText = obj.has("message") && !obj.get("message").isJsonNull() ? obj.get("message").getAsString() : "";
                String flagStr = obj.has("flag") && !obj.get("flag").isJsonNull() ? obj.get("flag").getAsString() : "SENT";
                MessageFlag flag = MessageFlag.valueOf(flagStr.toUpperCase());
                String id = Utils.generateId();
                String hash = Utils.sha256((developer == null ? "" : developer) + recipient + messageText + id);
                Message m = new Message(id, hash, developer, recipient, messageText, flag);
                addMessage(m);
            }
        }
    }
}
