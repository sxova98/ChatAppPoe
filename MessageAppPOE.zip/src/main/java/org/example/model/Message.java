package org.example.model;

import java.util.Objects;

/**
 * Immutable Message model used by the application.
 */
public class Message {
    private final String id;
    private final String hash;
    private final String sender;
    private final String recipient;
    private final String text;
    private final MessageFlag flag;

    public Message(String id, String hash, String sender, String recipient, String text, MessageFlag flag) {
        this.id = id;
        this.hash = hash;
        this.sender = sender;
        this.recipient = recipient;
        this.text = text;
        this.flag = flag;
    }

    public String getId() { return id; }
    public String getHash() { return hash; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getText() { return text; }
    public MessageFlag getFlag() { return flag; }

    @Override
    public String toString() {
        return "Message{" +
                "id='" + id + '\'' +
                ", hash='" + hash + '\'' +
                ", sender='" + sender + '\'' +
                ", recipient='" + recipient + '\'' +
                ", text='" + text + '\'' +
                ", flag=" + flag +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Message message = (Message) o;
        return Objects.equals(id, message.id) && Objects.equals(hash, message.hash);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, hash);
    }
}
