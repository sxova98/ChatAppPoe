package org.example.model;

/**
 * Message flags indicating classification.
 */
public enum MessageFlag {
    SENT,
    STORED,
    DISREGARD
}
