package org.example;

import org.example.store.MessageStore;
import org.example.ui.ConsoleMenu;

import java.nio.file.Path;

/**
 * Entry point for the console application.
 */
public class App {
    public static void main(String[] args) throws Exception {
        MessageStore store = new MessageStore();

        Path p = Path.of("src/main/resources/messages.json");
        if (p.toFile().exists()) {
            store.loadFromJson(p);
            System.out.println("Loaded messages from " + p);
        }

        ConsoleMenu menu = new ConsoleMenu(store);
        menu.run();

        System.out.println("\nFinal report:\n" + store.displayReport());
    }
}
