package org.example.gui;

import org.example.model.Message;
import org.example.store.MessageStore;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Simple Swing GUI for displaying sent messages.
 * This is intentionally lightweight so it runs without JavaFX.
 */
public class MessageGUI {
    public static void openWindow(MessageStore store) {
        JFrame frame = new JFrame("Message App - GUI");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(900, 400);

        String[] cols = new String[] {"ID", "Hash", "Sender", "Recipient", "Text", "Flag"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);
        JScrollPane scroll = new JScrollPane(table);

        // populate with sent messages
        List<Message> all = store.getSentMessages();
        for (Message m : all) {
            model.addRow(new Object[] {m.getId(), m.getHash(), m.getSender(), m.getRecipient(), m.getText(), m.getFlag()});
        }

        frame.getContentPane().add(scroll, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
