package org.example.ui;

import org.example.model.Message;
import org.example.store.MessageStore;

import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

/**
 * ConsoleMenu provides an interactive console-based UI for the MessageStore.
 */
public class ConsoleMenu {
    private final MessageStore store;
    private final Scanner sc = new Scanner(System.in);

    public ConsoleMenu(MessageStore store) {
        this.store = store;
    }

    public void run() {
        boolean exit = false;
        while (!exit) {
            printMenu();
            String input = sc.nextLine().trim();
            switch (input) {
                case "1" -> loadJson();
                case "2" -> displayAllSent();
                case "3" -> displayLongest();
                case "4" -> searchById();
                case "5" -> searchByRecipient();
                case "6" -> deleteByHash();
                case "7" -> showReport();
                case "8" -> openGui();
                case "9" -> exit = true;
                default -> System.out.println("Unknown option. Try again.");
            }
        }
        System.out.println("Exiting console menu.");
    }

    private void printMenu() {
        System.out.println("\n--- Message App Menu ---");
        System.out.println("1) Load messages from src/main/resources/messages.json");
        System.out.println("2) Display sender + recipient of all sent messages");
        System.out.println("3) Display the longest sent message");
        System.out.println("4) Search for message by ID");
        System.out.println("5) Search for messages by recipient");
        System.out.println("6) Delete message by hash");
        System.out.println("7) Display full report");
        System.out.println("8) Open simple GUI window");
        System.out.println("9) Exit");
        System.out.print("Select option: ");
    }

    private void loadJson() {
        try {
            store.loadFromJson(Path.of("src/main/resources/messages.json"));
            System.out.println("Messages loaded.");
        } catch (Exception e) {
            System.out.println("Failed to load JSON: " + e.getMessage());
        }
    }

    private void displayAllSent() {
        List<String> lines = store.displaySenderRecipientOfAllSent();
        lines.forEach(System.out::println);
    }

    private void displayLongest() {
        Optional<Message> m = store.getLongestSentMessage();
        m.ifPresentOrElse(msg -> System.out.println("Longest message: " + msg.getText()), () -> System.out.println("No sent messages." ));
    }

    private void searchById() {
        System.out.print("Enter message ID: ");
        String id = sc.nextLine().trim();
        store.searchByMessageId(id).ifPresentOrElse(System.out::println, () -> System.out.println("Not found."));
    }

    private void searchByRecipient() {
        System.out.print("Enter recipient: ");
        String r = sc.nextLine().trim();
        List<Message> msgs = store.searchByRecipient(r);
        if (msgs.isEmpty()) System.out.println("No messages for recipient.");
        else msgs.forEach(System.out::println);
    }

    private void deleteByHash() {
        System.out.print("Enter message hash to delete: ");
        String h = sc.nextLine().trim();
        boolean ok = store.deleteByHash(h);
        System.out.println(ok ? "Deleted." : "Not found.");
    }

    private void showReport() {
        System.out.println(store.displayReport());
    }

    private void openGui() {
        javax.swing.SwingUtilities.invokeLater(() -> org.example.gui.MessageGUI.openWindow(store));
    }
}
