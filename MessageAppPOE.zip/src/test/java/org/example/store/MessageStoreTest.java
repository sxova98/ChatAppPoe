package org.example.store;

import org.example.model.Message;
import org.example.model.MessageFlag;
import org.example.util.Utils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests covering the rubric:
 * - sentMessages populated
 * - longest message
 * - search by ID
 * - search by recipient
 * - delete by hash
 * - display report contains expected fields
 */
public class MessageStoreTest {
    private MessageStore store;
    private Message m1, m2, m3, m4, m5;

    @BeforeEach
    public void setup() {
        store = new MessageStore();
        m1 = new Message(Utils.generateId(), Utils.sha256("+27834557896" + "Did you get the cake?"), null, "+27834557896", "Did you get the cake?", MessageFlag.SENT);
        m2 = new Message(Utils.generateId(), Utils.sha256("+27838884567" + "Where are you? You are late! I have asked you to be on time."), null, "+27838884567", "Where are you? You are late! I have asked you to be on time.", MessageFlag.STORED);
        m3 = new Message(Utils.generateId(), Utils.sha256("+27834484567" + "Yohoooo, I am at your gate."), null, "+27834484567", "Yohoooo, I am at your gate.", MessageFlag.DISREGARD);
        m4 = new Message(Utils.generateId(), Utils.sha256("0838884567" + "+27838884567" + "It is dinner time!"), "0838884567", "+27838884567", "It is dinner time!", MessageFlag.SENT);
        m5 = new Message(Utils.generateId(), Utils.sha256("+27838884567" + "Ok, I am leaving without you."), null, "+27838884567", "Ok, I am leaving without you.", MessageFlag.SENT);

        store.addMessage(m1);
        store.addMessage(m2);
        store.addMessage(m3);
        store.addMessage(m4);
        store.addMessage(m5);
    }

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        List<Message> sent = store.getSentMessages();
        assertEquals(3, sent.size(), "There should be 3 sent messages");
        assertTrue(sent.contains(m1));
        assertTrue(sent.contains(m4));
        assertTrue(sent.contains(m5));
    }

    @Test
    public void testDisplayLongestMessage() {
        Optional<Message> longest = store.getLongestSentMessage();
        assertTrue(longest.isPresent());
        assertEquals(m4.getText(), longest.get().getText());
    }

    @Test
    public void testSearchForMessageID() {
        Optional<Message> found = store.searchByMessageId(m4.getId());
        assertTrue(found.isPresent());
        assertEquals(m4, found.get());
    }

    @Test
    public void testSearchAllMessagesForRecipient() {
        List<Message> messages = store.searchByRecipient("+27838884567");
        // m2 (stored), m4 (sent), m5 (sent)
        assertEquals(3, messages.size());
        assertTrue(messages.contains(m2));
        assertTrue(messages.contains(m4));
        assertTrue(messages.contains(m5));
    }

    @Test
    public void testDeleteMessageUsingHash() {
        String hash = m4.getHash();
        boolean deleted = store.deleteByHash(hash);
        assertTrue(deleted);
        assertFalse(store.getSentMessages().contains(m4));
        assertFalse(store.getMessageHashes().contains(hash));
    }

    @Test
    public void testDisplayReportContainsHashesAndRecipientsAndMessages() {
        String report = store.displayReport();
        assertTrue(report.contains("Message Hash:"));
        assertTrue(report.contains(m1.getRecipient()));
        assertTrue(report.contains(m1.getText()));
    }
}
