# Message App (NetBeans-ready)

This project implements a message processing application with:
- Parallel lists for Sent / Stored / Disregarded messages
- Message hashing and IDs
- Console menu and a simple Swing GUI
- JSON loader (src/main/resources/messages.json)
- JUnit 5 unit tests

How to run:
1. Import into NetBeans as a Maven project (select the project folder).
2. Run unit tests: `mvn test`
3. Run the app: `mvn exec:java` (exec plugin configured; main class org.example.App)
4. Generate Javadoc: `mvn javadoc:javadoc`
